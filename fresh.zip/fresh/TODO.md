# TODO: Add Search and Filter System to admin/feedback_table.php

- [ ] Uncomment session_start() in feedback_table.php
- [ ] Add created_at to SELECT query
- [ ] Add filter form above the table (search input, rating dropdown, date inputs, Apply/Reset buttons)
- [ ] Modify PHP to read GET params (search, rating_filter, start_date, end_date)
- [ ] Build conditional WHERE clauses for SQL query
- [ ] Use prepared statements for security
- [ ] Ensure form submits with GET to same page
- [ ] Reset button links to page without params
- [ ] Test the functionality
