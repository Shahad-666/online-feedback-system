<?php
// feedback_table.php : Handles the "Student Feedback Table" section for admin/feedbacklist.php
include("..//config/db.php");
// session_start();
// require admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ..//frontend/login.php");
    exit;
}

/* === Delete feedback === */
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    $stmt = $conn->prepare("DELETE FROM feedback WHERE feedback_id=?");
    $stmt->bind_param("i", $delete_id);
    $stmt->execute();
    if (isset($_GET['embed'])) {
        header("Location: feedbacklist.php?embed=1&section=feedback_table");
    } else {
        header("Location: feedbacklist.php");
    }
    exit;
}

/* === Fetch data === */
$search = trim($_GET['search'] ?? '');
$rating_filter = $_GET['rating_filter'] ?? 'all';
$start_date = trim($_GET['start_date'] ?? '');
$end_date = trim($_GET['end_date'] ?? '');

$sql = "
SELECT
f.feedback_id,
COALESCE(u.name,f.name) AS name,
COALESCE(u.email,f.email) AS email,
f.comments,
f.rating,
f.created_at,
u.age,
u.phone
FROM feedback f
LEFT JOIN users u ON TRIM(LOWER(f.email)) = TRIM(LOWER(u.email))
";

$where_clauses = [];
$params = [];
$types = '';

if (!empty($search)) {
    $where_clauses[] = "(COALESCE(u.name,f.name) LIKE ? OR COALESCE(u.email,f.email) LIKE ? OR f.comments LIKE ? OR CAST(f.rating AS CHAR) LIKE ?)";
    $search_param = '%' . $search . '%';
    $params[] = $search_param;
    $params[] = $search_param;
    $params[] = $search_param;
    $params[] = $search_param;
    $types .= 'ssss';
}

if ($rating_filter !== 'all' && is_numeric($rating_filter)) {
    $where_clauses[] = "f.rating = ?";
    $params[] = (int)$rating_filter;
    $types .= 'i';
}

if (!empty($start_date) && !empty($end_date)) {
    $where_clauses[] = "f.created_at BETWEEN ? AND ?";
    $params[] = $start_date . ' 00:00:00';
    $params[] = $end_date . ' 23:59:59';
    $types .= 'ss';
} elseif (!empty($start_date)) {
    $where_clauses[] = "f.created_at >= ?";
    $params[] = $start_date . ' 00:00:00';
    $types .= 's';
} elseif (!empty($end_date)) {
    $where_clauses[] = "f.created_at <= ?";
    $params[] = $end_date . ' 23:59:59';
    $types .= 's';
}

if (!empty($where_clauses)) {
    $sql .= " WHERE " . implode(" AND ", $where_clauses);
}

$sql .= " ORDER BY f.feedback_id DESC";

$stmt = $conn->prepare($sql);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();

$feedbackData = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $feedbackData[] = $row;
    }
}
$stmt->close();
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="icon" type="image/png" href="..//asset/image/f-s-i.png">
<link rel="shortcut icon" type="image/png" href="..//asset/image/f-s-i.png">
<link rel="stylesheet" href="..//asset/css/admin-credential.css">

</head>

<body>

<div class="overlay"></div>

<div class="card">
    <h5>Student Feedback Details</h5>

    <!-- Filters and Search -->
    <form method="GET" class="mb-3">
        <input type="hidden" name="embed" value="1">
        <input type="hidden" name="section" value="feedback_table">
        <div class="row g-2 mb-2">
            <div class="col-md-6">
                <label class="form-label">Search</label>
                <input type="text" name="search" class="form-control" placeholder="Search by name, email, comment, or rating" value="<?php echo htmlspecialchars($search); ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label">Rating Filter</label>
                <select name="rating_filter" class="form-select">
                    <option value="all" <?php echo ($rating_filter === 'all' || empty($rating_filter)) ? 'selected' : ''; ?>>All Ratings</option>
                    <option value="1" <?php echo $rating_filter === '1' ? 'selected' : ''; ?>>1 Star</option>
                    <option value="2" <?php echo $rating_filter === '2' ? 'selected' : ''; ?>>2 Stars</option>
                    <option value="3" <?php echo $rating_filter === '3' ? 'selected' : ''; ?>>3 Stars</option>
                    <option value="4" <?php echo $rating_filter === '4' ? 'selected' : ''; ?>>4 Stars</option>
                    <option value="5" <?php echo $rating_filter === '5' ? 'selected' : ''; ?>>5 Stars</option>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">Date Range</label>
                <div class="input-group">
                    <input type="date" name="start_date" class="form-control" value="<?php echo htmlspecialchars($start_date); ?>">
                    <span class="input-group-text">to</span>
                    <input type="date" name="end_date" class="form-control" value="<?php echo htmlspecialchars($end_date); ?>">
                </div>
            </div>
        </div>
        <div class="d-flex gap-2">
            <button type="submit" class="btn btn-primary">Apply Filters</button>
            <a href="feedbacklist.php?embed=1&section=feedback_table" class="btn btn-secondary">Reset Filters</a>
        </div>
    </form>

    <div class="table-responsive">
        <table class="table table-striped text-center align-middle">
            <thead class="table-primary">
                <tr>
                    <th>#</th><th class="desktop-hide-sm">Name</th>
                    <th class="desktop-hide-sm">Email</th>
                    <th class="desktop-hide-sm">Age</th>
                    <th class="desktop-hide-sm">Phone</th>
                    <th>Comment</th><th>Rating</th><th>Action</th>
                </tr>
            </thead>

            <tbody>
                <?php if (!empty($feedbackData)): $i=1; ?>
                    <?php foreach ($feedbackData as $fb): ?>
                    <tr>
                        <td><?php echo $i++; ?></td>
                        <td class="desktop-hide-sm"><?php echo htmlspecialchars($fb['name']); ?></td>
                        <td class="desktop-hide-sm"><?php echo htmlspecialchars($fb['email']); ?></td>
                        <td class="desktop-hide-sm"><?php echo htmlspecialchars($fb['age'] ?? 'N/A'); ?></td>
                        <td class="desktop-hide-sm"><?php echo htmlspecialchars($fb['phone'] ?? 'N/A'); ?></td>
                        <td class="comment-cell" style="text-align:left;">
                            <span class="desktop-hide-sm"><?php echo nl2br(htmlspecialchars($fb['comments'])); ?></span>
                        </td>
                        <td><?php echo htmlspecialchars($fb['rating']); ?></td>
                        <td>
                            <a href="feedbacklist.php?embed=1&section=feedback_table&delete_id=<?php echo $fb['feedback_id']; ?>"
                               class="btn btn-sm btn-danger"
                               onclick="return confirm('Delete this feedback?');">
                               Delete
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="8">No feedback found.</td></tr>
                <?php endif; ?>
            </tbody>

        </table>
    </div>
</div>

</body>
</html>
