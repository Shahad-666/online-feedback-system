<?php
include('../config/db.php');
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect input safely
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    // Prepare statement to prevent SQL injection
    $stmt = $conn->prepare("SELECT id, name, email, password, role FROM users WHERE email = ?");
    if ($stmt) {
        $stmt->bind_param("s", $email);
        $stmt->execute();

        $result = $stmt->get_result();

        if ($result && $result->num_rows > 0) {
            $user = $result->fetch_assoc();

            // Verify hashed password and check role
            if (password_verify($password, $user['password']) && $user['role'] === 'admin') {
                // Start session and set admin role
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['role'] = 'admin';

                // Redirect to admin dashboard
                header("Location: feedbacklist.php");
                exit;
            } else {
                $error = "Invalid credentials or insufficient permissions.";
            }
        } else {
            $error = "No admin account found with this email.";
        }

        $stmt->close();
    } else {
        $error = "Database error: failed to prepare query.";
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Login</title>
  <link rel="icon" type="image/png" href="../asset/image/f-s-i.png">
  <link rel="shortcut icon" type="image/png" href="../asset/image/f-s-i.png">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="../asset/css/admin-login.css">
</head>
<body>
<div class="login-container">
  <div class="login-box shadow-lg p-4">
    <h2 class="text-center mb-4">Admin Login</h2>

    <?php if (isset($error)): ?>
      <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <form action="login.php" method="POST">
      <div class="mb-3 text-start">
        <label for="email" class="form-label">Email Address</label>
        <input
          type="email"
          id="email"
          name="email"
          placeholder="Enter admin email"
          class="form-control"
          maxlength="100"
          required
        >
      </div>

      <div class="mb-4 text-start">
        <label for="password" class="form-label">Password</label>
        <input
          type="password"
          id="password"
          name="password"
          placeholder="Enter password"
          class="form-control"
          minlength="8"
          maxlength="20"
          pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@$!%*?&]).{8,20}"
          title="Password must be 8–20 characters long with at least 1 uppercase, 1 lowercase, 1 number, 1 special character."
          required
        >
      </div>

      <button type="submit" name="submit" class="btn btn-primary w-100">Login</button>
    </form>
  </div>
</div>
</body>
</html>
