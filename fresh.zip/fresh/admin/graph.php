<?php
// graph.php : Handles the "Graph" section for admin/feedbacklist.php
include("..//config/db.php");
// session_start();
// require admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ..//frontend/login.php");
    exit;
}

/* === Fetch rating counts === */
$ratingCount = [1=>0,2=>0,3=>0,4=>0,5=>0];
$sql = "SELECT rating, COUNT(*) as cnt FROM feedback GROUP BY rating";
$result = $conn->query($sql);
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $r = intval($row['rating']);
        if (isset($ratingCount[$r])) {
            $ratingCount[$r] = intval($row['cnt']);
        }
    }
}
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="icon" type="image/png" href="..//asset/image/f-s-i.png">
<link rel="shortcut icon" type="image/png" href="..//asset/image/f-s-i.png">
<link rel="stylesheet" href="..//asset/css/admin-credential.css">

</head>

<body>
<div class="overlay"></div>
<div class="card">
    <h5>Rating Overview</h5>
    <canvas id="ratingChart" style="max-height:240px;"></canvas>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
(function(){
    const data = <?php echo json_encode(array_values($ratingCount)); ?>;
    const ctx = document.getElementById('ratingChart').getContext('2d');

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['1 Star','2 Stars','3 Stars','4 Stars','5 Stars'],
            datasets: [{
                label: 'Rating count',
                data: data,
                backgroundColor: ['#f44336','#ffb74d','#ffd54f','#81c784','#4caf50'],
                borderRadius: 6
            }]
        },
        options: { 
            responsive:true, 
            scales:{ y:{ beginAtZero:true, precision:0 } } 
        }
    });
})();
</script>

</body>
</html>
