<?php
include("..//config/db.php");
// session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ..//frontend/login.php");
    exit;
}

$questions = [];
$result = $conn->query("SELECT id, question_text, created_at FROM feedback_questions ORDER BY id ASC");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $questions[] = $row;
    }
}

$add_msg = '';
if (isset($_POST['add_question'])) {
    $qtext = trim($_POST['question_text'] ?? '');
    if ($qtext === '') {
        $add_msg = "<div class='alert alert-warning'>Enter question.</div>";
    } else {
        $stmt = $conn->prepare("INSERT INTO feedback_questions (question_text) VALUES (?)");
        $stmt->bind_param("s", $qtext);
        if ($stmt->execute()) {
            $add_msg = "<div class='alert alert-success'>Added.</div>";
        } else {
            $add_msg = "<div class='alert alert-danger'>DB error.</div>";
        }
        $stmt->close();
    }
}

if (isset($_GET['delete_question'])) {
    $delid = intval($_GET['delete_question']);
    $stmt = $conn->prepare("DELETE FROM feedback_questions WHERE id=?");
    $stmt->bind_param("i", $delid);
    $stmt->execute();
    if (isset($_GET['embed'])) {
        header("Location: feedbacklist.php?embed=1&section=add_questions");
    } else {
        header("Location: feedbacklist.php");
    }
    exit;
}
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="icon" type="image/png" href="..//asset/image/f-s-i.png">
<link rel="shortcut icon" type="image/png" href="..//asset/image/f-s-i.png">
<link rel="stylesheet" href="..//asset/css/admin-credential.css">
</head>
<body>
<div class="overlay"></div>
    <div class="card">
        <h5>Manage Feedback Questions</h5>
        <?php if ($add_msg) echo $add_msg; ?>
        <form method="post" enctype="multipart/form-data">
            <div class="mb-2">
                <label class="form-label">New question</label>
                <input type="text" name="question_text" class="form-control" placeholder="Enter question text">
            </div>
            <button name="add_question" class="btn btn-primary">Add Question</button>
        </form>
        <hr>
        <h6 class="mt-2">Active Questions</h6>
        <?php if (empty($questions)): ?>
            <p class="text-muted small">No questions added yet.</p>
        <?php else: ?>
            <ul class="list-group">
                <?php foreach ($questions as $q): ?>
                <li class="list-group-item d-flex justify-content-between align-items-start">
                    <div>
                        <div class="fw-semibold"><?php echo htmlspecialchars($q['question_text']); ?></div>
                        <small class="text-muted">ID: <?php echo $q['id']; ?> — <?php echo $q['created_at']; ?></small>
                    </div>
                    <div>
                        <a href="feedbacklist.php?embed=1&section=add_questions&delete_question=<?php echo $q['id']; ?>"
                           class="btn btn-sm btn-danger"
                           onclick="return confirm('Delete this question?');">
                           Delete
                        </a>
                    </div>
                </li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </div>
</body>
</html>
