<?php
include("..//config/db.php");
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ..//frontend/login.php");
    exit;
}

function load_admin_record($conn, $id) {
    $stmt = $conn->prepare("SELECT id, name, email, age, phone, role, created_at, avatar FROM users WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res->fetch_assoc();
    $res->free();
    $stmt->close();
    return $row ?: null;
}

$admin = [
    'id' => 0,
    'name' => 'Admin',
    'email' => 'admin@example.com',
    'age' => '',
    'phone' => '',
    'role' => 'admin',
    'created_at' => '',
    'avatar' => ''
];

if (!empty($_SESSION['user_id'])) {
    $aid = intval($_SESSION['user_id']);
    $r = load_admin_record($conn, $aid);
    if ($r) {
        $admin = $r;
    }
} else {
    $ares = $conn->query("SELECT id, name, email, age, phone, role, created_at, avatar FROM users WHERE role='admin' LIMIT 1");
    if ($ares && $ar = $ares->fetch_assoc()) {
        $admin = $ar;
    }
}

$profile_msg = '';
$pass_msg = '';
$avatar_success_path = '';

if (isset($_POST['user_id_profile'], $_FILES['profile_image']) && $_FILES['profile_image']['error'] !== UPLOAD_ERR_NO_FILE) {
    $uid = intval($_POST['user_id_profile']);
    $file = $_FILES['profile_image'];

    $maxSize = 2 * 1024 * 1024;
    $allowedMime = ['image/jpeg', 'image/png', 'image/gif'];
    $allowedExt = ['jpg', 'jpeg', 'png', 'gif'];

    if ($file['error'] !== UPLOAD_ERR_OK) {
        $profile_msg = "<div class='alert alert-danger'>Failed to upload image (error code {$file['error']}).</div>";
    } elseif ($file['size'] > $maxSize) {
        $profile_msg = "<div class='alert alert-warning'>Image too large. Max 2 MB.</div>";
    } else {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);

        if (!in_array($mime, $allowedMime, true)) {
            $profile_msg = "<div class='alert alert-warning'>Invalid image type.</div>";
        } else {
            $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            if (!in_array($ext, $allowedExt, true)) {
                $map = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/gif' => 'gif'];
                $ext = $map[$mime] ?? 'jpg';
            }

            $uploadDir = __DIR__ . '/../frontend/uploads/avatars/';
            $webDir = 'frontend/uploads/avatars/';

            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }

            if ($profile_msg === '') {
                $filename = 'user_' . $uid . '_' . time() . '.' . $ext;
                $destination = $uploadDir . $filename;
                $webPath = $webDir . $filename;

                if (move_uploaded_file($file['tmp_name'], $destination)) {
                    $ust = $conn->prepare("UPDATE users SET avatar = ? WHERE id = ?");
                    $ust->bind_param("si", $webPath, $uid);
                    if ($ust->execute()) {
                        $profile_msg = "<div class='alert alert-success'>Profile image updated.</div>";
                        $avatar_success_path = $webPath;
                    } else {
                        $profile_msg = "<div class='alert alert-danger'>DB error.</div>";
                        @unlink($destination);
                    }
                    $ust->close();
                } else {
                    $profile_msg = "<div class='alert alert-danger'>Failed to move uploaded file.</div>";
                }
            }
        }
    }

    $ar = load_admin_record($conn, $uid);
    if ($ar) $admin = $ar;
}

/* === Handle profile update === */
if (isset($_POST['save_profile']) && isset($_POST['user_id_profile'])) {
    $uid = intval($_POST['user_id_profile']);
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $age = intval($_POST['age'] ?? 0);
    $phone = trim($_POST['phone'] ?? '');

    if ($name === '' || $email === '') {
        $profile_msg = "<div class='alert alert-warning'>Name and email required.</div>";
    } else {
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ? AND id <> ?");
        $stmt->bind_param("si", $email, $uid);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($res && $res->num_rows > 0) {
            $profile_msg = "<div class='alert alert-danger'>Email already exists.</div>";
        } else {
            $ust = $conn->prepare("UPDATE users SET name=?, email=?, age=?, phone=? WHERE id=?");
            $ust->bind_param("ssisi", $name, $email, $age, $phone, $uid);
            if ($ust->execute()) {
                $profile_msg = "<div class='alert alert-success'>Profile updated.</div>";
            } else {
                $profile_msg = "<div class='alert alert-danger'>DB error.</div>";
            }
            $ust->close();
        }
        $stmt->close();
    }

    $ar = load_admin_record($conn, $uid);
    if ($ar) $admin = $ar;
}

/* === Change password === */
if (isset($_POST['change_password']) && isset($_POST['new_password']) && isset($_POST['user_id_pw'])) {
    $uid = intval($_POST['user_id_pw']);
    $newpw = trim($_POST['new_password']);
    if ($newpw === '') {
        $pass_msg = "<div class='alert alert-warning'>Enter new password.</div>";
    } else {
        $hash = password_hash($newpw, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE users SET password=? WHERE id=?");
        $stmt->bind_param("si", $hash, $uid);
        if ($stmt->execute()) {
            $pass_msg = "<div class='alert alert-success'>Password updated.</div>";
        } else {
            $pass_msg = "<div class='alert alert-danger'>DB error.</div>";
        }
        $stmt->close();
    }
    $ar = load_admin_record($conn, $uid);
    if ($ar) $admin = $ar;
}


/* === Delete question === */
if (isset($_GET['delete_question'])) {
    $delid = intval($_GET['delete_question']);
    $stmt = $conn->prepare("DELETE FROM feedback_questions WHERE id=?");
    $stmt->bind_param("i", $delid);
    $stmt->execute();
    if (isset($_GET['embed'])) {
        header("Location: feedbacklist.php?embed=1&section=add_questions");
    } else {
        header("Location: feedbacklist.php");
    }
    exit;
}
/* === Delete feedback === */
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    $stmt = $conn->prepare("DELETE FROM feedback WHERE feedback_id=?");
    $stmt->bind_param("i", $delete_id);
    $stmt->execute();
    if (isset($_GET['embed'])) {
        header("Location: feedbacklist.php?embed=1&section=feedback_table");
    } else {
        header("Location: feedbacklist.php");
    }
    exit;
}

/* === Logout === */
if (isset($_POST['logout'])) {
    session_destroy();
    header("Location: ..//frontend/index.php");
    exit;
}

/* === Fetch data === */
$questions = [];
$qres = $conn->query("SELECT id,question_text,created_at FROM feedback_questions ORDER BY id ASC");
if ($qres) while ($r = $qres->fetch_assoc()) $questions[] = $r;

$sql = "
SELECT 
f.feedback_id,
COALESCE(u.name,f.name) AS name,
COALESCE(u.email,f.email) AS email,
f.comments,
f.rating,
u.age,
u.phone
FROM feedback f
LEFT JOIN users u ON TRIM(LOWER(f.email)) = TRIM(LOWER(u.email))
ORDER BY f.feedback_id DESC
";
$result = $conn->query($sql);

$ratingCount = [1=>0,2=>0,3=>0,4=>0,5=>0];
$feedbackData = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $feedbackData[] = $row;
        $r = intval($row['rating']);
        if (isset($ratingCount[$r])) $ratingCount[$r]++;
    }
}

/* === If embed mode, print section === */
if (isset($_GET['embed']) && $_GET['embed'] == '1') {
    $section = $_GET['section'] ?? 'admin_profile';

    if ($section === 'add_questions') {
        include __DIR__ . '/add_questions.php';
        exit;
    }

    if ($section === 'feedback_table') {
        include __DIR__ . '/feedback_table.php';
        exit;
    }

    if ($section === 'graph') {
        include __DIR__ . '/graph.php';
        exit;
    }

    /* === ADMIN PROFILE SECTION === */
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="icon" type="image/png" href="..//asset/image/f-s-i.png">
<link rel="shortcut icon" type="image/png" href="..//asset/image/f-s-i.png">
<link rel="stylesheet" href="..//asset/css/admin-credential.css">
</head>

<body>

<div class="overlay"></div>

<div class="card">
    <h5>Admin Credentials</h5>
    <p class="muted">Edit your admin details here.</p>

    <?php
        if ($profile_msg) echo $profile_msg;
        if ($pass_msg) echo $pass_msg;
    ?>

    <div class="d-flex align-items-center gap-3 mb-3">
        <div class="avatar-preview" id="avatarPreview">
            <?php
            if (!empty($admin['avatar']) && file_exists(__DIR__ . '/../' . $admin['avatar'])) {
                echo '<img src="../' . htmlspecialchars($admin['avatar']) . '" alt="avatar">';
            } else {
                echo strtoupper(substr(htmlspecialchars($admin['name']),0,1));
            }
            ?>
        </div>

        <form method="post" enctype="multipart/form-data">
            <input type="hidden" name="user_id_profile" value="<?php echo (int)$admin['id']; ?>">
            <div class="mb-2">
                <label class="form-label">Profile Image</label>
                <input type="file" name="profile_image" accept="image/*" class="form-control">
            </div>
            <button type="submit" class="btn btn-primary">Upload</button>
        </form>
    </div>

    <form method="post" class="mb-3">
        <input type="hidden" name="user_id_profile" value="<?php echo (int)$admin['id']; ?>">

        <div class="row g-2 mb-2">
            <div class="col-md-6">
                <label class="form-label field-label">Name</label>
                <input type="text" name="name" class="form-control" 
                       value="<?php echo htmlspecialchars($admin['name']); ?>" required>
            </div>
            <div class="col-md-6">
                <label class="form-label field-label">Email</label>
                <input type="email" name="email" class="form-control"
                       value="<?php echo htmlspecialchars($admin['email']); ?>" required>
            </div>
            <div class="col-md-6">
                <label class="form-label field-label">Phone</label>
                <input type="text" name="phone" class="form-control"
                       value="<?php echo htmlspecialchars($admin['phone']); ?>">
            </div>
            <div class="col-md-6">
                <label class="form-label field-label">Age</label>
                <input type="number" name="age" class="form-control"
                       value="<?php echo htmlspecialchars($admin['age']); ?>">
            </div>
        </div>

        <button type="submit" name="save_profile" class="btn btn-success">Save</button>
    </form>

    <hr>
    <h6>Change Password</h6>

    <form method="post">
        <input type="hidden" name="user_id_pw" value="<?php echo (int)$admin['id']; ?>">
        <div class="mb-2">
            <label class="form-label">New password</label>
            <input type="password" name="new_password" class="form-control" placeholder="Enter new password">
        </div>
        <button type="submit" name="change_password" class="btn btn-warning">Change Password</button>
    </form>
</div>

<!-- Notify parent -->
<?php
if (!empty($avatar_success_path)) {
    $payload = [
        'type' => 'profile_updated',
        'avatar' => $avatar_success_path,
        'name' => $admin['name'],
        'email' => $admin['email']
    ];
    echo "<script>parent.postMessage(" . json_encode($payload) . ", '*');</script>";
} elseif (!empty($profile_msg)) {
    $payload = [
        'type' => 'profile_updated',
        'avatar' => $admin['avatar'],
        'name' => $admin['name'],
        'email' => $admin['email']
    ];
    echo "<script>parent.postMessage(" . json_encode($payload) . ", '*');</script>";
}
?>

</body>
</html>

<?php
exit;
}

/* === END OF EMBED SECTIONS === */
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin - Feedback & Questions</title>
<link rel="icon" type="image/png" href="..//asset/image/f-s-i.png">
<link rel="shortcut icon" type="image/png" href="..//asset/image/f-s-i.png">
<link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet" />
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="..//asset/css/admin-feedbacklist.css" rel="stylesheet">


</head>

<body>

<div class="app-shell">

    <!-- ===== TOPBAR (MOBILE) ===== -->
    <div class="topbar" role="banner">
        <button class="menu-btn" id="mobileMenuBtn" aria-label="Open menu">☰</button>
        <div class="title">Admin Panel</div>
        <div style="width:36px;"></div>
    </div>

    <!-- ===== SIDEBAR START ===== -->
    <div class="sidebar" id="sidebar" role="navigation" aria-label="Admin sidebar">

        <!-- ★ NEW BUTTON FOR CLOSING SIDEBAR ON MOBILE ★ -->
        <button class="sidebar-close-btn" onclick="toggleSidebar(false)">☰</button>

        <!-- PROFILE PIC -->
        <div class="profile-pic" id="sidebarAvatar">
        <?php
            if (!empty($admin['avatar']) && file_exists(__DIR__ . '/../' . $admin['avatar'])) {
                echo '<img src="../' . htmlspecialchars($admin['avatar']) . '" alt="avatar">';
            } else {
                echo strtoupper(substr(htmlspecialchars($admin['name']),0,1));
            }
        ?>
        </div>

        <h5 id="sidebarName"><?php echo htmlspecialchars($admin['name']); ?></h5>
        <p class="email" id="sidebarEmail"><?php echo htmlspecialchars($admin['email']); ?></p>

        <!-- SIDEBAR MENU BUTTONS -->
        <div class="btns" role="menu">
            <button id="btn_profile" class="sbtn" type="button" onclick="loadSection('admin_profile')">👤 Admin Credentials</button>
            <button id="btn_add_questions" class="sbtn" type="button" onclick="loadSection('add_questions')">➕ Add Questions</button>
            <button id="btn_feedback_table" class="sbtn" type="button" onclick="loadSection('feedback_table')">📋 Feedback Table</button>
            <button id="btn_graph" class="sbtn" type="button" onclick="loadSection('graph')">📊 Graph</button>
        </div>

        <form method="post" class="logout-form" onsubmit="return confirm('Logout from admin?');">
            <input type="hidden" name="logout" value="1">
            <button type="submit">Logout</button>
        </form>

    </div>
    <!-- ===== SIDEBAR END ===== -->

    <!-- ===== MAIN CONTENT AREA ===== -->
    <div class="main-area">
        <iframe id="contentFrame" class="iframe-wrap"
                src="feedbacklist.php?embed=1&section=admin_profile&ts=<?php echo time(); ?>"></iframe>
    </div>

</div> <!-- end app-shell -->

<!-- ===== BEGIN SCRIPTS ===== -->
<script src="..//asset/js/feedbacklist.js"></script>

</body>
</html>
