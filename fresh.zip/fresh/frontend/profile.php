<?php
session_start();

// require_once '..//config/db.php';
include('..//config/db.php');
/* === Determine user === */
$user_id = null;

if (!empty($_POST['user_id'])) {
    $user_id = (int)$_POST['user_id'];
    $_SESSION['user_id'] = $user_id;
} elseif (!empty($_SESSION['user_id'])) {
    $user_id = (int)$_SESSION['user_id']; 
} elseif (!empty($_POST['email'])) {
    $email = trim($_POST['email']);

    $stmt = $conn->prepare("SELECT id FROM users WHERE email=?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        $user_id = (int)$row['id'];
        $_SESSION['user_id'] = $user_id;
    }
    $stmt->close();
}

if (!$user_id) {
    header("Location: login.php");
    exit;
}

/* === Save Profile Update === */
$message = '';
$avatar_msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save') {

    $name    = trim($_POST['name'] ?? '');
    $email   = trim($_POST['email'] ?? '');
    $age     = (int)($_POST['age'] ?? 0);
    $phone   = trim($_POST['phone'] ?? '');
    $newpass = trim($_POST['password'] ?? '');

    if ($name === '' || $email === '') {
        $message = "Name and email are required.";
    } else {

        $avatar_web_path = null;

        /* === Avatar Upload === */
        if (!empty($_FILES['profile_image']) && $_FILES['profile_image']['error'] !== UPLOAD_ERR_NO_FILE) {

            $file = $_FILES['profile_image'];
            $maxSize = 2 * 1024 * 1024;
            $allowedMime = ['image/jpeg', 'image/png', 'image/gif'];
            $allowedExt  = ['jpg','jpeg','png','gif'];

            if ($file['error'] !== UPLOAD_ERR_OK) {
                $avatar_msg = "Error uploading file.";
            } elseif ($file['size'] > $maxSize) {
                $avatar_msg = "Image too large."; 
            } else {
                $finfo = finfo_open(FILEINFO_MIME_TYPE);
                $mime  = finfo_file($finfo, $file['tmp_name']);
                finfo_close($finfo);

                if (in_array($mime, $allowedMime)) {

                    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                    if (!in_array($ext, $allowedExt)) {
                        $ext = ['image/jpeg'=>'jpg','image/png'=>'png','image/gif'=>'gif'][$mime];
                    }

                    $uploadDir = __DIR__ . '/uploads/avatars/';
                    $webDir    = 'uploads/avatars/';

                    if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

                    $filename = "user_{$user_id}_" . time() . ".$ext";
                    $destination = $uploadDir . $filename;
                    $webPath = $webDir . $filename;

                    if (move_uploaded_file($file['tmp_name'], $destination)) {
                        $avatar_web_path = $webPath;
                    }
                }
            }
        }

        try {
            $updateQuery = "UPDATE users SET name=?,email=?,age=?,phone=?";
            $params = [$name, $email, $age, $phone];

            if ($newpass !== '') {
                $updateQuery .= ",password=?";
                $hash = password_hash($newpass, PASSWORD_DEFAULT);
                $params[] = $hash;
            }

            if ($avatar_web_path) {
                $updateQuery .= ",avatar=?";
                $params[] = $avatar_web_path;
            }

            $updateQuery .= " WHERE id=?";
            $params[] = $user_id;

            $stmt = $conn->prepare($updateQuery);

            // Prepare types string for bind_param
            $types = "";
            $bind_values = [];

            // name, email, age, phone (string, string, int, string)
            $types .= "ssis";
            $bind_values[] = &$name;
            $bind_values[] = &$email;
            $bind_values[] = &$age;
            $bind_values[] = &$phone;

            // Optional password parameter
            if ($newpass !== '') {
                $types .= "s";
                $bind_values[] = &$hash;
            }

            // Optional avatar parameter
            if ($avatar_web_path) {
                $types .= "s";
                $bind_values[] = &$avatar_web_path;
            }

            // user_id for WHERE clause (int)
            $types .= "i";
            $bind_values[] = &$user_id;

            // Binding params dynamically
            array_unshift($bind_values, $types);
            call_user_func_array([$stmt, 'bind_param'], $bind_values);

            $stmt->execute();
            $stmt->close();

            $message = "Profile updated successfully.";

        } catch (Exception $e) {
            $message = "Failed to update profile.";
        }
    }
}

/* === Load User === */
$stmt = $conn->prepare("SELECT * FROM users WHERE id=?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

?>
<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>User Profile</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="icon" type="image/png" href="..//asset/image/f-s-i.png">
<link rel="shortcut icon" type="image/png" href="..//asset/image/f-s-i.png">
<link rel="stylesheet" href="..//asset/css/profile.css">
</head>
<body>

<div class="overlay"></div>

<!-- Hamburger -->
<button class="hamburger" onclick="toggleSidebar()">☰</button>

<div class="container-box">

    <!-- Sidebar -->
    <div id="sidebar" class="sidebar">

        <div class="text-center">
            <div class="rounded-circle bg-light text-dark mx-auto mb-3"
                style="width:110px;height:110px;overflow:hidden;display:flex;justify-content:center;align-items:center;font-size:40px;font-weight:bold;">
                <?php
                if (!empty($user['avatar']) && file_exists(__DIR__.'/'.$user['avatar'])) {
                    echo '<img src="'.$user['avatar'].'" style="width:100%;height:100%;object-fit:cover;">';
                } else {
                    echo strtoupper(substr($user['name'],0,1));
                }
                ?>
            </div>
            <h5><?php echo htmlspecialchars($user['name']); ?></h5>
            <p class="sidebar-email"><?php echo htmlspecialchars($user['email']); ?></p>
        </div>

        <div class="text-center mt-4">
            <button id="openFeedbackBtn" class="btn btn-light text-primary" onclick="openFeedback()">Feedback</button>
            <button id="backProfileBtn" class="btn btn-outline-light mt-2" onclick="closeFeedback()" style="display:none;">Back</button>
        </div>

    </div>

    <!-- Main Section -->
    <div class="form-section">

        <div id="profileContainer" class="profile-form">

            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="action" value="save">

                <div class="row">
                    <div class="col-md-6">
                        <label>Name</label>
                        <input class="form-control" name="name" readonly value="<?php echo $user['name']; ?>">
                    </div>

                    <div class="col-md-6">
                        <label>Phone</label>
                        <input class="form-control" name="phone" readonly value="<?php echo $user['phone']; ?>">
                    </div>

                    <div class="col-md-6">
                        <label>Age</label>
                        <input class="form-control" name="age" readonly value="<?php echo $user['age']; ?>">
                    </div>

                    <div class="col-md-6">
                        <label>Email</label>
                        <input class="form-control" name="email" readonly value="<?php echo $user['email']; ?>">
                    </div>

                    <div class="col-md-6">
                        <label>Password</label>
                        <input class="form-control" type="password" name="password" readonly>
                    </div>

                    <div class="col-md-6">
                        <label>Profile Image</label>
                        <input class="form-control" type="file" name="profile_image" disabled>
                    </div>
                </div>

                <div class="mt-4 d-flex justify-content-between">
                    <a href="login.php" class="btn btn-primary">&lt;&lt; Prev</a>

                    <div>
                        <button type="button" id="editBtn" class="btn btn-success">Edit</button>
                        <button type="submit" id="saveBtn" class="btn btn-success" style="display:none;">Save</button>
                    </div>

                    <a href="next.php" class="btn btn-primary">Next &gt;&gt;</a>
                </div>

                <?php if ($message): ?>
                    <p class="text-success text-center mt-3 fw-bold"><?php echo $message; ?></p>
                <?php endif; ?>

            </form>

        </div>

        <!-- Feedback -->
        <iframe id="feedbackFrame" class="iframe-wrap"></iframe>

    </div>
</div>


<script src="..//asset/js/profile.js"></script>

</body>
</html>
