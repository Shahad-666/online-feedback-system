<?php
session_start();
include("..//config/db.php");

// ensure logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
$user_id = (int)$_SESSION['user_id'];

// fetch user name, email & avatar
$user_stmt = $conn->prepare("SELECT name, email, avatar FROM users WHERE id = ?");
$user_stmt->bind_param("i", $user_id);
$user_stmt->execute();
$user_res = $user_stmt->get_result();
$user = $user_res->fetch_assoc();
$user_stmt->close();

$name_value = $user['name'] ?? '';
$email_value = $user['email'] ?? '';
$avatar_value = $user['avatar'] ?? '';

$message = '';
$showConfirmation = false;
$confirmData = [];

// handle logout

// handle logout
if (isset($_POST['logout'])) {
    session_unset();
    session_destroy();

    // Force redirect the entire browser (not inside iframe)
    echo "<script>window.top.location.href = 'index.php';</script>";
    exit;
}



// load dynamic questions from feedback_questions
$questions = [];
$qres = $conn->query("SELECT id, question_text FROM feedback_questions ORDER BY id ASC");
if ($qres) {
    while ($qr = $qres->fetch_assoc()) {
        $questions[] = $qr;
    }
}

// handle form submit
if (isset($_POST['submit'])) {
    // collect general comment & rating
    $comment = trim($_POST['comment'] ?? '');
    $rating = (int)($_POST['rating'] ?? 0);

    // collect answers for dynamic questions
    $answers = [];
    $missing = false;
    foreach ($questions as $q) {
        $key = 'q_' . $q['id'];
        $val = trim($_POST[$key] ?? '');
        if ($val === '') {
            $missing = true;
            break;
        }
        $answers[] = ['id' => $q['id'], 'question' => $q['question_text'], 'answer' => $val];
    }

    if ($missing) {
        $message = "<div class='alert alert-warning mt-3'>Please answer all questions.</div>";
    } elseif ($rating < 1 || $rating > 5) {
        $message = "<div class='alert alert-warning mt-3'>Please select a rating (1-5).</div>";
    } else {
        // Build combined comments (questions + answers + optional comment)
        $combined = "";
        foreach ($answers as $i => $a) {
            $combined .= "Q" . ($i+1) . " (" . $a['question'] . "): " . $a['answer'] . "\n";
        }
        $combined .= "\nComment: " . $comment;

        // insert into feedback table (user_id, name, email, comments, rating)
        $stmt = $conn->prepare("INSERT INTO feedback (user_id, name, email, comments, rating) VALUES (?, ?, ?, ?, ?)");
        if ($stmt === false) {
            $message = "<div class='alert alert-danger mt-3'>Prepare failed: " . htmlspecialchars($conn->error) . "</div>";
        } else {
            $stmt->bind_param("isssi", $user_id, $name_value, $email_value, $combined, $rating);
            if ($stmt->execute()) {
                // Insert individual answers into feedback_answers table
                $feedback_id = $conn->insert_id;
                $answer_stmt = $conn->prepare("INSERT INTO feedback_answers (feedback_id, question_id, answer) VALUES (?, ?, ?)");
                if ($answer_stmt === false) {
                    $message = "<div class='alert alert-danger mt-3'>Prepare failed for feedback_answers: " . htmlspecialchars($conn->error) . "</div>";
                } else {
                    foreach ($answers as $a) {
                        $answer_stmt->bind_param("iis", $feedback_id, $a['id'], $a['answer']);
                        if (!$answer_stmt->execute()) {
                            $message = "<div class='alert alert-danger mt-3'>Error inserting answers: " . htmlspecialchars($answer_stmt->error) . "</div>";
                            break;
                        }
                    }
                    $answer_stmt->close();

                    if (empty($message)) {
                        // show confirmation details only if no errors on inserting answers
                        $showConfirmation = true;
                        $confirmData = [
                            'answers' => $answers,
                            'comment' => nl2br(htmlspecialchars($comment)),
                            'rating' => $rating,
                        ];
                    }
                }
            } else {
                $message = "<div class='alert alert-danger mt-3'>Error executing query: " . htmlspecialchars($stmt->error) . "</div>";
            }
            $stmt->close();
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Feedback</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="icon" type="image/png" href="..//asset/image/f-s-i.png">
<link rel="shortcut icon" type="image/png" href="..//asset/image/f-s-i.png">

  <link rel="stylesheet" href="..//asset/css/feedbackfinal.css">



</head>
<body>
<div class="card">

  <!-- PROFILE - full width top area -->
  <div class="profile-area">
    <div class="profile-left">
      <div class="profile-pic">
        <?php
          // If avatar path exists, use it. Otherwise, show the initial letter.
          if (!empty($avatar_value)) {
              echo '<img src="' . htmlspecialchars($avatar_value) . '" alt="avatar">';
          } else {
              echo strtoupper(substr($name_value,0,1));
          }
        ?>
      </div>

      <div class="profile-info">
        <div class="profile-name-email">
          <h4><?php echo htmlspecialchars($name_value); ?></h4>
          <p><?php echo htmlspecialchars($email_value); ?></p>
        </div>
      </div>
    </div>

    <div class="profile-actions">
      <form method="post" style="margin:0;">
        <button type="submit" name="logout" class="btn-logout">Logout</button>
      </form>
    </div>
  </div>

  <!-- FEEDBACK FORM (below the profile area) -->
  <div class="right">
    <?php if ($showConfirmation && !empty($confirmData)): ?>
      <div class="confirm-card">
        <h3>✅ Feedback Received</h3>
        <?php foreach ($confirmData['answers'] as $idx => $a): ?>
          <p><strong><?php echo ($idx+1) . ". " . htmlspecialchars($a['question']); ?></strong></p>
          <pre><?php echo htmlspecialchars($a['answer']); ?></pre>
        <?php endforeach; ?>

        <p class="mt-2"><strong>Comments:</strong></p>
        <pre><?php echo $confirmData['comment']; ?></pre>

        <p class="mt-2"><strong>Rating:</strong> <span style="color:#ffd166;"><?php echo str_repeat("★", max(0, min(5, (int)$confirmData['rating']))); ?></span></p>

        <div style="margin-top:14px; text-align:right;">
          <a href="feedbackfinal.php" class="btn btn-light" style="font-weight:700; color:#2575fc;">Leave another</a>
        </div>
      </div>
    <?php else: ?>
      <h3 style="margin-top:0;">Submit Your Feedback</h3>
      <?php if ($message !== '') echo $message; ?>

      <?php if (empty($questions)): ?>
        <div class="alert alert-info">No feedback questions available right now. Please try again later.</div>
      <?php else: ?>
      <form id="finalFeedbackForm" method="post" action="feedbackfinal.php">
        <?php foreach ($questions as $i => $q): ?>
          <div class="mb-3">
            <label for="q_<?php echo $q['id']; ?>"><?php echo ($i+1) . '️⃣ ' . htmlspecialchars($q['question_text']); ?></label>
            <input id="q_<?php echo $q['id']; ?>" type="text" name="q_<?php echo $q['id']; ?>" placeholder="Type your answer..." required>
          </div>
        <?php endforeach; ?>

        <div class="mb-3">
          <label for="comment">Your Comments</label>
          <textarea id="comment" name="comment" placeholder="Write your feedback here..."></textarea>
        </div>

        <div class="rating">
          <input type="radio" id="star5" name="rating" value="5">
          <label for="star5">★</label>

          <input type="radio" id="star4" name="rating" value="4">
          <label for="star4">★</label>

          <input type="radio" id="star3" name="rating" value="3">
          <label for="star3">★</label>

          <input type="radio" id="star2" name="rating" value="2">
          <label for="star2">★</label>

          <input type="radio" id="star1" name="rating" value="1">
          <label for="star1">★</label>
        </div>




        <div class="buttons">
          <button type="submit" name="submit" class="btn-submit">SUBMIT ➡</button>
        </div>
      </form>
      <?php endif; ?>
    <?php endif; ?>
  </div>
</div>

<script>
  // Update star colors when rating changes (right-to-left coloring).
  (function() {
    const ratingInputs = Array.from(document.querySelectorAll('.rating input'));
    const ratingLabels = Array.from(document.querySelectorAll('.rating label'));

    function updateStars(selectedValue) {
      // Color stars whose numeric value is >= selectedValue (so left-side higher-value stars light up).
      ratingLabels.forEach(label => {
        const forId = label.getAttribute('for');
        const input = document.getElementById(forId);
        if (!input) return;
        const val = parseInt(input.value, 10);
        if (selectedValue > 0 && val >= selectedValue) {
          label.classList.add('active');
        } else {
          label.classList.remove('active');
        }
      });
    }

    // Handle hover to preview right-to-left filling
    ratingLabels.forEach(label => {
      const forId = label.getAttribute('for');
      const input = document.getElementById(forId);
      if (!input) return;

      label.addEventListener('mouseenter', () => {
        const val = parseInt(input.value, 10) || 0;
        updateStars(val);
      });

      label.addEventListener('mouseleave', () => {
        // restore to currently selected value (if any)
        const checked = ratingInputs.find(i => i.checked);
        updateStars(checked ? parseInt(checked.value, 10) : 0);
      });

      // clicking label will check associated input; change handler below will handle coloring
    });

    // Attach change handler to inputs
    ratingInputs.forEach(input => {
      input.addEventListener('change', function() {
        const val = parseInt(this.value, 10) || 0;
        updateStars(val);
      });
    });

    // On page load, if any rating is pre-checked, update UI
    const checked = ratingInputs.find(i => i.checked);
    if (checked) {
      updateStars(parseInt(checked.value, 10));
    }
  })();

  // Form validation: ensure rating selected before submit
  document.getElementById('finalFeedbackForm')?.addEventListener('submit', function(e){
    const ratingChecked = Array.from(document.querySelectorAll('input[name="rating"]')).some(i => i.checked);
    if (!ratingChecked) {
      alert('Please select a rating (1-5).');
      e.preventDefault();
      return;
    }
  });
</script>
</body>
</html>
