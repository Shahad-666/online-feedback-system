<!DOCTYPE html>
<html>
<head>
    <title>Forgot Password</title>
    <meta charset="UTF-8">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="..//asset/css/login.css">
</head>
<body>
    <div class="login-container">
  <div class="login-box shadow-lg p-4">

    <h2 class="text-center mb-4">Forgot Password</h2>
 <div class="mb-3 text-start">
    
    <form method="post" action="send-password-reset.php">

        <label for="email" class="form-label">Email</label>
        <input type="email" name="email" id="email" class="form-control" placeholder="Enter Email">
</div>
        <button type="submit" name="submit" class="btn btn-primary w-100">Send</button>

    </form>
</div>
</div>
</body>
</html>