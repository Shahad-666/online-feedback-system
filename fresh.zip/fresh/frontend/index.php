<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Online Feedback System</title>
<link rel="icon" type="image/png" href="..//asset/image/f-s-i.png">
<link rel="shortcut icon" type="image/png" href="..//asset/image/f-s-i.png">


<link rel="stylesheet" href="..//asset/css/style.css">
</head>
<body>
<header>
  <div class="title-section">
    <h3 id="typewriter"></h3>
  </div>

  <div class="button-space">
    <button class="btn btn-login" onclick="window.location.href='login.php'">Login</button>
    <button class="btn btn-register" onclick="window.location.href='register.php'">Register</button>
  </div>
</header>

<script>
  // Typewriter effect
  const text1 = "ONLINE FEEDBACK SYSTEM";
  const text2 = "Your feedback shapes better services.";
  const heading = document.getElementById("typewriter");
  let i = 0;

  function typeText1() {
    if (i < text1.length) {
      heading.textContent += text1.charAt(i);
      i++;
      setTimeout(typeText1, 150); // typing speed
    } else {
      // After first text completes, show second line after a small delay
      setTimeout(() => {
        const subText = document.createElement("p");
        subText.textContent = text2;
        subText.classList.add("sub-heading");
        heading.insertAdjacentElement("afterend", subText);
      }, 500);
    }
  }

  // Start typing once page loads
  window.onload = typeText1;
</script>

<main>
  <div class="main-overlay">
    <h1>Welcome to the Online<br>Feedback System</h1>
    <p>The Online Feedback System allows users to submit feedback quickly and efficiently. 
    It helps institutions and organizations improve their services based on real user input. 
    Join us in making things better — your feedback matters!</p>
    <button class="btn-feedback" onclick="window.location.href='login.php'">Give Feedback</button>
  </div>
</main>


<footer>
  © 2025 Online Feedback System | All Rights Reserved
</footer>
</body>
</html>
