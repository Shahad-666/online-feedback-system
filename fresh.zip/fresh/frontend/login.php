<?php
include('..//config/db.php');
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect input safely
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    // Prepare statement to prevent SQL injection
    $stmt = $conn->prepare("SELECT id, role, password FROM users WHERE email = ?");
    if ($stmt) {
        $stmt->bind_param("s", $email);
        $stmt->execute();

        $result = $stmt->get_result();

        if ($result && $result->num_rows > 0) {
            $user = $result->fetch_assoc();

            // Verify hashed password
            if (password_verify($password, $user['password'])) {
                // Store session data
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['role'] = $user['role'];

                // Redirect based on role
                if ($user['role'] === 'student') {
                    header("Location: profile.php");
                    exit;
                } elseif ($user['role'] === 'admin') {
                    header("Location: ..//admin/feedbacklist.php");
                    exit;
                }
            } else {
                echo "<script>alert('Incorrect password.');</script>";
            }
        } else {
            echo "<script>alert('No user found with this email.');</script>";
        }

        $stmt->close();
    } else {
        echo "<script>alert('Database error: failed to prepare query.');</script>";
    }

    $conn->close();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>User Login</title>
  <link rel="icon" type="image/png" href="..//asset/image/f-s-i.png">
  <link rel="shortcut icon" type="image/png" href="..//asset/image/f-s-i.png">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="..//asset/css/login.css">
</head>
<body>
<div class="login-container">
  <div class="login-box shadow-lg p-4">
    <h2 class="text-center mb-4">User Login</h2>
    <form action="login.php" method="POST">
      <div class="mb-3 text-start">
        <label for="email" class="form-label">Email Address</label>
        <input 
          type="email" 
          id="email" 
          name="email" 
          placeholder="Enter your email" 
          class="form-control" 
          maxlength="100" 
          required
        >
      </div>

      <div class="mb-4 text-start">
        <label for="password" class="form-label">Password</label>
        <input 
          type="password" 
          id="password" 
          name="password" 
          placeholder="Enter password" 
          class="form-control" 
          minlength="8" 
          maxlength="20" 
          pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@$!%*?&]).{8,20}" 
          title="Password must be 8–20 characters long with at least 1 uppercase, 1 lowercase, 1 number, 1 special character." 
          required
        >
      </div>

      <button type="submit" name="submit" class="btn btn-primary w-100">Login</button>

      <div class="register-text text-center mt-3">
        Don't have an account? <a href="register.php">Register here</a>
      </div>

       <!-- 🔹 Added Forgot Password Link -->

      <div class="register-text mt-3">
        <a href="send-password-reset.php">Forgot password?</a>
      </div>
    </form>
  </div>
</div>
</body>
</html>
