<?php include("..//config/db.php");
//  provides $conn and aliases
 $mysqli = $mysqli ?? $conn;
  $token = $_GET["token"] ?? '';
  if (!$token) { die("No token provided"); 
 }
  $token_hash = hash('sha256', $token); 
 $sql = "SELECT * FROM users WHERE reset_token_hash = ?";
  $stmt = $mysqli->prepare($sql); 
 if (!$stmt) {
  die("Prepare failed: " . $mysqli->error);
  } 
 $stmt->bind_param("s", $token_hash);
  if (!$stmt->execute()) {
    die("Execute failed: " . $stmt->error);
  }
  $result = $stmt->get_result();
 $user = $result->fetch_assoc();
  if (!$user) { die("Token not found"); 
 } 
 if (strtotime($user["reset_token_expires_at"]) <= time()) {
  die("Token has expired");
  } 
//  token valid — show the reset form below 
 ?>
<!DOCTYPE html>
  <html lang="en">
    <head>
      <meta charset="utf-8"> <meta name="viewport" content="width=device-width, initial-scale=1"> 
      <title>Reset Password</title>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="..//asset/css/login.css"> 
      </head> 
      <body> 
        <div class="login-container">
            <div class="login-box shadow-lg p-4"> 
            <h2>Reset Password</h2> 
            <form method="post" action="..//backend/process-password-reset.php">
                <input type="hidden" name="token" value="<?= htmlspecialchars($token) ?>">
                <div class="mb-3 text-start">
                <label for="password" class="form-label">New password</label> 
                <input type ="password" id="password" name="password"   class="form-control" placeholder="new password" required>
</div>

<div class="mb-3 text-start">
                  <label for="password_confirmation" class="form-label">Repeat password</label>
                  <input type="password" id="password_confirmation" name="password_confirmation"   class="form-control" placeholder="new password" required>
</div>
                    <button type="submit" name="submit" class="btn btn-primary w-100">Send</button>

                  </form>
                  </div>
                  </div>
                  </body> 
                  </html>