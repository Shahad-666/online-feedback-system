<?php
include("..//config/db.php"); // provides $conn, $mysqli, $connect
include("../backend/email_validator.php"); // Include the new email validator

$message = '';
$messageType = 'success'; // 'success', 'danger', etc.

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // handle form submission
    // validate email
    // send password reset email
    // show success or error message
    $email = $_POST["email"] ?? '';

    $emailError = null;
    if (!validate_email_real($email, $emailError)) {
        $message = "Email validation failed: " . htmlspecialchars($emailError ?: "Invalid email.");
        $messageType = 'danger';
    } else {
        $token = bin2hex(random_bytes(16));
        $token_hash = hash("sha256", $token);
        $expiry = date("Y-m-d H:i:s", time() + 60 * 30);

        // Update users table
        $sql = "UPDATE users SET reset_token_hash = ?, reset_token_expires_at = ? WHERE email = ?";

        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            $message = "DB prepare error: " . $conn->error;
            $messageType = 'danger';
        } elseif (!$stmt->bind_param("sss", $token_hash, $expiry, $email)) {
            $message = "DB bind_param error: " . $stmt->error;
            $messageType = 'danger';
        } else {
            $exec = $stmt->execute();
            if ($exec === false) {
                $message = "DB execute error: " . $stmt->error;
                $messageType = 'danger';
            } elseif ($conn->affected_rows === 0) {
                $message = "No account found with that email address.";
                $messageType = 'danger';
            } else {
                // send mail
                $mail = require __DIR__ . "/../backend/mailer.php";
                $mail->setFrom("knowingwhat359@gmail.com", "YourAppName"); // setFrom should be email and a name
                $mail->addAddress($email);
                $mail->Subject = "Password Reset";

                $mail->Body = <<<END
                Click <a href="https://student-feedback-system.ct.ws/frontend/reset-password.php?token=$token">here</a> to reset your password.
                END;

                try {
                    if (!$mail->send()) {
                        $message = "Mailer send returned false. Error: " . $mail->ErrorInfo;
                        $messageType = 'danger';
                    } else {
                        $message = "Message sent, please check your inbox (and spam).";
                        $messageType = 'success';
                    }
                } catch (Exception $e) {
                    $message = "Message could not be sent. Mailer exception: " . $mail->ErrorInfo;
                    $messageType = 'danger';
                }
            }
        }
    }
} else {
    // show HTML form
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Forgot Password</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="..//asset/css/login.css">
</head>
<body>
    <div class="login-container">
        <div class="login-box shadow-lg p-4">
            <h2 class="text-center mb-4">Forgot Password</h2>
            <div class="mb-3 text-start">
                <?php if ($message): ?>
                    <div class="alert alert-<?php echo $messageType; ?>" role="alert">
                        <?php echo $message; ?>
                    </div>
                <?php endif; ?>
                <form method="post" action="send-password-reset.php">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" name="email" id="email" class="form-control" placeholder="Enter Email" required>
                    <button type="submit" name="submit" class="btn btn-login w-100 mt-3">Send</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
