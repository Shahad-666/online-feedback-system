<?php
include("config/db.php");

$sql = "SELECT email FROM users LIMIT 1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo $row['email'];
} else {
    echo "No users found";
}
?>
