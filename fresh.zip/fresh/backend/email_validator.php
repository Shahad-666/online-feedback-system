<?php

function validate_email_real($email, &$errorMessage = null, $enableSmtpCheck = true) {
    // Step 1: Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errorMessage = "Invalid email format.";
        return false;
    }

    // Step 2: Extract domain and check MX records
    $domain = substr(strrchr($email, "@"), 1);
    if (!$domain) {
        $errorMessage = "Email domain not found.";
        return false;
    }

    if (!checkdnsrr($domain, "MX")) {
        $errorMessage = "No MX records found for domain.";
        return false;
    }

    // If SMTP check disabled, skip step 3 and return true here
    if (!$enableSmtpCheck) {
        return true;
    }

    // Step 3: SMTP mailbox existence check
    $mxHosts = [];
    $mxWeights = [];
    if (!getmxrr($domain, $mxHosts, $mxWeights)) {
        $errorMessage = "Could not get MX records for domain.";
        return false;
    }

    // Sort by weight ascending
    array_multisort($mxWeights, $mxHosts);

    $fromEmail = "validate@" . $domain; // dummy sender email
    $couldConnect = false;

    foreach ($mxHosts as $host) {
        $connection = @fsockopen($host, 25, $errno, $errstr, 5);
        if (!$connection) {
            continue; // try next MX host
        }
        $couldConnect = true;
        stream_set_timeout($connection, 5);

        // Read SMTP server response
        $response = fgets($connection);
        if (substr($response, 0, 3) != '220') {
            fclose($connection);
            continue;
        }

        // Say EHLO
        fputs($connection, "EHLO $domain\r\n");
        $ehloResponse = "";
        while (($line = fgets($connection)) !== false) {
            $ehloResponse .= $line;
            if (substr($line, 3, 1) == " ") {
                break;
            }
        }

        // Try MAIL FROM
        fputs($connection, "MAIL FROM:<$fromEmail>\r\n");
        $mailFromResponse = fgets($connection);
        if (substr($mailFromResponse, 0, 3) != "250") {
            fclose($connection);
            continue;
        }

        // Try RCPT TO
        fputs($connection, "RCPT TO:<$email>\r\n");
        $rcptToResponse = fgets($connection);
        if (substr($rcptToResponse, 0, 3) == "250") {
            // Mailbox exists
            fputs($connection, "QUIT\r\n");
            fclose($connection);
            return true;
        } elseif (substr($rcptToResponse, 0, 3) == "550") {
            // Mailbox does not exist
            fputs($connection, "QUIT\r\n");
            fclose($connection);
            $errorMessage = "Email address does not exist on mail server.";
            return false;
        } else {
            // SMTP server does not allow verification or respond unknown
            fputs($connection, "QUIT\r\n");
            fclose($connection);
            $errorMessage = "Cannot verify email. Try again.";
            return false;
        }
    }

    if (!$couldConnect) {
        $errorMessage = "SMTP connection to mail servers failed, skipping SMTP validation.";
        // Return true to allow validation to pass because SMTP check is skipped due to connectivity failure
        return true;
    }

    $errorMessage = "Could not verify email on any mail server.";
    return false;
}
?>
