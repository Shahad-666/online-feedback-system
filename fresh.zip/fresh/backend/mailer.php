<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . "/../vendor/autoload.php";

$mail = new PHPMailer(true);

// Use SMTP instead of PHP's mail() function
$mail->isSMTP();
$mail->SMTPAuth = true;

// SMTP server configuration for Brevo
$mail->Host = 'smtp-relay.brevo.com';
$mail->Username = '9cd081001@smtp-brevo.com';
$mail->Password = '4PgHkvxNZ3AKbOyV';
$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Use TLS encryption
$mail->Port = 587;

$mail->isHtml(true);

return $mail;
?>
