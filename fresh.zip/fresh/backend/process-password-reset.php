<?php
include("..//config/db.php");
$mysqli = $mysqli ?? $conn;

$token = $_POST["token"] ?? '';
if (!$token) {
    $error = "No token provided";
}

$password = $_POST["password"] ?? '';
$confirm = $_POST["password_confirmation"] ?? '';

if (!isset($error) && ($password === '' || $confirm === '')) {
    $error = "Please provide password and confirmation";
}
if (!isset($error) && $password !== $confirm) {
    $error = "Passwords do not match";
}
// if (strlen($password) < 8) {
//     die("Password must be at least 8 characters");
// }

if (!isset($error) && !preg_match('/(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}/', $password)) {
    $error = "Password must be at least 8 characters long, include at least 1 number, 1 lowercase letter, 1 uppercase letter, and 1 special character.";
}

$password_hash = password_hash($password, PASSWORD_DEFAULT);

$token_hash = hash('sha256', $token);

// find user by token
$sql = "SELECT * FROM users WHERE reset_token_hash = ?";
$stmt = $mysqli->prepare($sql);
if (!$stmt) {
    die("Prepare failed: " . $mysqli->error);
}
$stmt->bind_param("s", $token_hash);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    die("Token not found");
}

if (strtotime($user["reset_token_expires_at"]) <= time()) {
    die("Token has expired");
}

// update the same column used in registration
$sql = "UPDATE users
SET password = ?,
    reset_token_hash = NULL,
    reset_token_expires_at = NULL
WHERE id = ?";

$stmt = $mysqli->prepare($sql);
if (!$stmt) {
    die("Prepare failed (update): " . $mysqli->error);
}

$stmt->bind_param("si", $password_hash, $user["id"]);

if (!$stmt->execute()) {
    die("DB execute error (update): " . $stmt->error);
}

echo "Password updated. You can now login with your new password.";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Password Reset</title>
  <link rel="icon" type="image/png" href="..//asset/image/f-s-i.png">
  <link rel="shortcut icon" type="image/png" href="..//asset/image/f-s-i.png">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="..//asset/css/style.css">
  <link rel="stylesheet" href="..//asset/css/login.css">
</head>
<body>
<header>
  <div class="title-section">
    <h3 id="typewriter"></h3>
  </div>

  <div class="button-space">
    <button class="btn btn-login" onclick="window.location.href='..//frontend/login.php'">Login</button>
    <button class="btn btn-register" onclick="window.location.href='..//frontend/register.php'">Register</button>
  </div>
</header>

<main>
  <div class="overlay"></div>
  <div class="login-container">
    <div class="login-box shadow-lg p-4">
      <h2 class="text-center mb-4">Password Reset</h2>
      <?php if (isset($success)): ?>
        <div class="alert alert-success text-center">
          <?php echo htmlspecialchars($success); ?>
        </div>
        <div class="text-center mt-3">
          <button type="button" class="btn btn-primary w-100" onclick="window.location.href='..//frontend/login.php'">Go to Login</button>
        </div>
      <?php elseif (isset($error)): ?>
        <div class="alert alert-danger text-center">
          <?php echo htmlspecialchars($error); ?>
        </div>
        <div class="text-center mt-3">
          <a href="..//frontend/login.php" class="btn btn-secondary w-100">Back to Login</a>
        </div>
      <?php endif; ?>
    </div>
  </div>
</main>

<footer>
  © 2025 Online Feedback System | All Rights Reserved
</footer>

<script>
  // Typewriter effect
  const text1 = "ONLINE FEEDBACK SYSTEM";
  const text2 = "Your feedback shapes better services.";
  const heading = document.getElementById("typewriter");
  let i = 0;

  function typeText1() {
    if (i < text1.length) {
      heading.textContent += text1.charAt(i);
      i++;
      setTimeout(typeText1, 150);
    } else {
      setTimeout(() => {
        const subText = document.createElement("p");
        subText.textContent = text2;
        subText.classList.add("sub-heading");
        heading.insertAdjacentElement("afterend", subText);
      }, 500);
    }
  }

  window.onload = typeText1;
</script>
</body>
</html>
