
/* Toggle Sidebar */
function toggleSidebar(){
    document.getElementById("sidebar").classList.toggle("show");
}

/* Edit button */
document.getElementById("editBtn").onclick = function(){
    document.querySelectorAll("input").forEach(x=>{
        x.removeAttribute("readonly");
        x.removeAttribute("disabled");
    });
    editBtn.style.display="none";
    saveBtn.style.display="inline-block";
};

/* Feedback */
function openFeedback(){
    document.getElementById("profileContainer").style.display="none";
    document.getElementById("feedbackFrame").style.display="block";
    document.getElementById("feedbackFrame").src="feedbackfinal.php?ts="+Date.now();
    document.getElementById("openFeedbackBtn").style.display="none";
    document.getElementById("backProfileBtn").style.display="inline-block";
}

function closeFeedback(){
    document.getElementById("profileContainer").style.display="block";
    document.getElementById("feedbackFrame").style.display="none";
    document.getElementById("openFeedbackBtn").style.display="inline-block";
    document.getElementById("backProfileBtn").style.display="none";
}


window.addEventListener("pageshow", function(event) {
    if (event.persisted) {
        window.location.reload();
    }
});