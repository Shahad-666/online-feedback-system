const frame = document.getElementById('contentFrame');
const btns = {
    admin_profile: document.getElementById('btn_profile'),
    add_questions: document.getElementById('btn_add_questions'),
    feedback_table: document.getElementById('btn_feedback_table'),
    graph: document.getElementById('btn_graph')
};

const sidebar = document.getElementById('sidebar');
const mobileMenuBtn = document.getElementById('mobileMenuBtn');

function clearActive(){
    Object.values(btns).forEach(b => b.classList.remove('active'));
}

function loadSection(name){
    clearActive();
    if (btns[name]) btns[name].classList.add('active');
    frame.src = 'feedbacklist.php?embed=1&section=' + encodeURIComponent(name) + '&ts=' + Date.now();

    /* auto-close sidebar on mobile */
    if (window.innerWidth <= 900) toggleSidebar(false);
}

function toggleSidebar(forceOpen){
    if (typeof forceOpen === 'boolean') {
        sidebar.classList.toggle('collapsed', !forceOpen);
    } else {
        sidebar.classList.toggle('collapsed');
    }
}

mobileMenuBtn.addEventListener('click', ()=>{
    toggleSidebar();
});

/* highlight default on load */
(function init(){
    clearActive();
    btns.admin_profile.classList.add('active');
    if (window.innerWidth <= 900) {
        sidebar.classList.add('collapsed');
    }
})();

// Listen for updates from iframe (profile updates / avatar upload)
window.addEventListener('message', function(ev){
    if (!ev.data) return;
    try {
        const msg = ev.data;
        if (msg.type === 'profile_updated') {
            if (msg.avatar) {
                // update avatar image (parent path expects ../uploads/...)
                const avatarWrap = document.getElementById('sidebarAvatar');
                if (avatarWrap) {
                    // If payload already contains ../ prefix keep it; otherwise add ../
                    const srcBase = String(msg.avatar).startsWith('../') ? String(msg.avatar) : ('../' + String(msg.avatar));
                    // Append timestamp to bust cache
                    const src = srcBase + '?ts=' + Date.now();
                    avatarWrap.innerHTML = '<img src="' + src + '" alt="avatar">';
                }
            }
            if (msg.name) {
                const n = document.getElementById('sidebarName');
                if (n) n.textContent = msg.name;
            }
            if (msg.email) {
                const e = document.getElementById('sidebarEmail');
                if (e) e.textContent = msg.email;
            }
        }
    } catch(e){
        // fail silently
        console.error(e);
    }
}, false);

// Ensure pageshow restores state correctly (back/forward)
window.addEventListener("pageshow", function(event) {
    if (event.persisted) {
        window.location.reload();
    }
});
